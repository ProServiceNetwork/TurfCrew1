<?php

return [

    'confirmation' => 'Bunu etmək istədiyinizdən əminsiniz?',

    'actions' => [

        'cancel' => [
            'label' => 'İmtina',
        ],

        'confirm' => [
            'label' => 'Təsdiqlə',
        ],

        'submit' => [
            'label' => 'Təqdim et',
        ],

    ],

];
