<?php

return [

    'single' => [

        'label' => 'جیاکردنەوە',

        'modal' => [

            'heading' => 'جیاکردنەوەی :label',

            'actions' => [

                'detach' => [
                    'label' => 'جیاکردنەوە',
                ],

            ],

        ],

        'notifications' => [

            'detached' => [
                'title' => 'جیاکرایەوە',
            ],

        ],

    ],

    'multiple' => [

        'label' => 'جیاکردنەوەی هەڵبژێردراوەکان',

        'modal' => [

            'heading' => 'جیاکردنەوەی هەڵبژێردراوەکانی :label',

            'actions' => [

                'detach' => [
                    'label' => 'جیاکردنەوە',
                ],

            ],

        ],

        'notifications' => [

            'detached' => [
                'title' => 'جیاکرایەوە',
            ],

        ],

    ],

];
