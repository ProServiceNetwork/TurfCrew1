<?php

return [

    'throttled' => [
        'title' => 'Liian monta yritystä',
        'body' => 'Yritä uudelleen :seconds sekunnin päästä.',
    ],

];
