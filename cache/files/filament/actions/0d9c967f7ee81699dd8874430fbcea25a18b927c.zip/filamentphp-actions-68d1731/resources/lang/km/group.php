<?php

return [

    'trigger' => [
        'label' => 'សកម្មភាព',
    ],

];
