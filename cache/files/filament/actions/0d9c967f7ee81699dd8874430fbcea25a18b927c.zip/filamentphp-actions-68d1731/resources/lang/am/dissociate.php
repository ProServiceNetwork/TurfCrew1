<?php

return [

    'single' => [

        'label' => 'አለያይ',
        'modal' => [

            'heading' => ':labelን አለያይ',
            'actions' => [

                'dissociate' => [

                    'label' => 'አለያይ',
                ],
            ],
        ],
        'notifications' => [

            'dissociated' => [

                'title' => 'ተለያይቶዋል',
            ],
        ],
    ],
    'multiple' => [

        'label' => 'የተመረጡትን አለያይ',
        'modal' => [

            'heading' => 'የተመረጡ :labelን አለያይ',
            'actions' => [

                'dissociate' => [

                    'label' => 'አለያይ',
                ],
            ],
        ],
        'notifications' => [

            'dissociated' => [

                'title' => 'ሁሉም ተለያይተዋል',
            ],
        ],
    ],
];
