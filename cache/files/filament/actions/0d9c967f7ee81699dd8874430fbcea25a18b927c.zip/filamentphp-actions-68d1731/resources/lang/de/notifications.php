<?php

return [

    'throttled' => [
        'title' => 'Zu viele Versuche',
        'body' => 'Bitte versuchen Sie es in :seconds Sekunden erneut.',
    ],

];
