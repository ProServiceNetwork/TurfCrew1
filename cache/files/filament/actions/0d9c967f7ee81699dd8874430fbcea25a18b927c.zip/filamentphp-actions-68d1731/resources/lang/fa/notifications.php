<?php

return [

    'throttled' => [
        'title' => 'تلاش بیش از حد مجاز',
        'body' => 'لطفا بعد از :seconds ثانیه دوباره تلاش کنید.',
    ],

];
