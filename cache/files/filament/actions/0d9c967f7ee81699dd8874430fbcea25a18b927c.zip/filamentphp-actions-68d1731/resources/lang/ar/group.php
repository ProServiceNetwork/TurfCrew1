<?php

return [

    'trigger' => [
        'label' => 'الإجراءات',
    ],

];
