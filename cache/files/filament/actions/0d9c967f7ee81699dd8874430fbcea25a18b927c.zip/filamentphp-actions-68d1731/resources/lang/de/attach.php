<?php

return [

    'single' => [

        'label' => 'Verknüpfen',

        'modal' => [

            'heading' => ':label verknüpfen',

            'fields' => [

                'record_id' => [
                    'label' => 'Eintrag',
                ],

            ],

            'actions' => [

                'attach' => [
                    'label' => 'Verknüpfen',
                ],

                'attach_another' => [
                    'label' => 'Verknüpfen & weiterer Eintrag',
                ],

            ],

        ],

        'notifications' => [

            'attached' => [
                'title' => 'Verknüpft',
            ],

        ],

    ],

];
