<?php

return [

    'single' => [

        'label' => 'Paihna',

        'modal' => [

            'heading' => ':Label paihna',

            'actions' => [

                'detach' => [
                    'label' => 'Paihna',
                ],

            ],

        ],

        'notifications' => [

            'detached' => [
                'title' => 'Paih a ni.',
            ],

        ],

    ],

    'multiple' => [

        'label' => 'Thlan ho paih thenna',

        'modal' => [

            'heading' => ':Label thlan ho paih thenna',

            'actions' => [

                'detach' => [
                    'label' => 'Paihna',
                ],

            ],

        ],

        'notifications' => [

            'detached' => [
                'title' => 'Paih then a ni.',
            ],

        ],

    ],

];
