<?php

return [

    'single' => [

        'label' => 'Edit',

        'modal' => [

            'heading' => ':Label edit na',

            'actions' => [

                'save' => [
                    'label' => 'Thlak danglamna',
                ],

            ],

        ],

        'notifications' => [

            'saved' => [
                'title' => 'A in save e.',
            ],

        ],

    ],

];
