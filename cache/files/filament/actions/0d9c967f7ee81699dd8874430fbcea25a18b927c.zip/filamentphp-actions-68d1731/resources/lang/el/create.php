<?php

return [

    'single' => [

        'label' => 'Προσθήκη :label',

        'modal' => [

            'heading' => 'Δημιουργία :label',

            'actions' => [

                'create' => [
                    'label' => 'Δημιουργία',
                ],

                'create_another' => [
                    'label' => 'Δημιουργία & δημιουργία νέου',
                ],

            ],

        ],

        'notifications' => [

            'created' => [
                'title' => 'Δημιουργήθηκε επιτυχώς',
            ],

        ],

    ],

];
