<?php

return [

    'single' => [

        'label' => 'បង្ខំ​លុប',

        'modal' => [

            'heading' => 'បង្ខំ​លុប :label',

            'actions' => [

                'delete' => [
                    'label' => 'លុប',
                ],

            ],

        ],

        'notifications' => [

            'deleted' => [
                'title' => 'បានលុប',
            ],

        ],

    ],

    'multiple' => [

        'label' => 'បង្ខំការលុបដែលបានជ្រើសរើស',

        'modal' => [

            'heading' => 'បង្ខំការលុបដែលបានជ្រើសរើស :label',

            'actions' => [

                'delete' => [
                    'label' => 'លុប',
                ],

            ],

        ],

        'notifications' => [

            'deleted' => [
                'title' => 'បានលុប',
            ],

        ],

    ],

];
