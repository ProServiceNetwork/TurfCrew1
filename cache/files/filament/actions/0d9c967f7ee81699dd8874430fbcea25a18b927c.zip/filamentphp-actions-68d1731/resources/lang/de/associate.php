<?php

return [

    'single' => [

        'label' => 'Verknüpfen',

        'modal' => [

            'heading' => ':label verknüpfen',

            'fields' => [

                'record_id' => [
                    'label' => 'Eintrag',
                ],

            ],

            'actions' => [

                'associate' => [
                    'label' => 'Verknüpfen',
                ],

                'associate_another' => [
                    'label' => 'Verknüpfen & weiterer Eintrag',
                ],

            ],

        ],

        'notifications' => [

            'associated' => [
                'title' => 'Verknüpft',
            ],

        ],

    ],

];
