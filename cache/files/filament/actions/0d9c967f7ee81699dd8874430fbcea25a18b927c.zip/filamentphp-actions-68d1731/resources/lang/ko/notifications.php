<?php

return [

    'throttled' => [
        'title' => '너무 많은 시도',
        'body' => ':seconds초 후에 다시 시도해 주세요.',
    ],

];
