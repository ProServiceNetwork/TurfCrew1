<?php

return [

    'single' => [

        'label' => 'Erota',

        'modal' => [

            'heading' => 'Erota :label',

            'actions' => [

                'dissociate' => [
                    'label' => 'Erota',
                ],

            ],

        ],

        'notifications' => [

            'dissociated' => [
                'title' => 'Erotettu',
            ],

        ],

    ],

    'multiple' => [

        'label' => 'Erota valitut',

        'modal' => [

            'heading' => 'Erota valitut :label',

            'actions' => [

                'dissociate' => [
                    'label' => 'Erota valitut',
                ],

            ],

        ],

        'notifications' => [

            'dissociated' => [
                'title' => 'Erotettu',
            ],

        ],

    ],

];
