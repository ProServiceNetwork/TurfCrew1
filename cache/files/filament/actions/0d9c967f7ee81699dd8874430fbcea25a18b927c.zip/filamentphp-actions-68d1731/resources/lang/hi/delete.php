<?php

return [

    'single' => [

        'label' => 'हटाएँ',

        'modal' => [

            'heading' => ':label हटाएँ',

            'actions' => [

                'delete' => [
                    'label' => 'हटाएँ',
                ],

            ],

        ],

        'notifications' => [

            'deleted' => [
                'title' => 'हटा दिया',
            ],

        ],

    ],

    'multiple' => [

        'label' => 'चयनित हटाएँ',

        'modal' => [

            'heading' => 'चयनित :label हटाएँ',

            'actions' => [

                'delete' => [
                    'label' => 'चयनित हटाएँ',
                ],

            ],

        ],

        'notifications' => [

            'deleted' => [
                'title' => 'हटा दिया',
            ],

        ],

    ],

];
