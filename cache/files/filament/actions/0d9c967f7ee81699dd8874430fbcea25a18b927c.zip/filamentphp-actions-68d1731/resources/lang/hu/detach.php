<?php

return [

    'single' => [

        'label' => 'Leválasztás',

        'modal' => [

            'heading' => ':label leválasztása',

            'actions' => [

                'detach' => [
                    'label' => 'Leválasztás',
                ],

            ],

        ],

        'notifications' => [

            'detached' => [
                'title' => 'Leválasztva',
            ],

        ],

    ],

    'multiple' => [

        'label' => 'Kijelöltek leválasztása',

        'modal' => [

            'heading' => 'Kijelölt :label leválasztása',

            'actions' => [

                'detach' => [
                    'label' => 'Kijelöltek leválasztása',
                ],

            ],

        ],

        'notifications' => [

            'detached' => [
                'title' => 'Leválasztva',
            ],

        ],

    ],

];
