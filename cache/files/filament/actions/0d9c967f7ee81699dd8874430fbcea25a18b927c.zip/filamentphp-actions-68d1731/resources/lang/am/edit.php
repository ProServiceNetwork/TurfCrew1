<?php

return [

    'single' => [

        'label' => 'አድስ',
        'modal' => [

            'heading' => ':labelን አድስ',
            'actions' => [

                'save' => [

                    'label' => 'አስቀምጥ',
                ],
            ],
        ],
        'notifications' => [

            'saved' => [

                'title' => 'እድሳቱ ተጠናቆዋል',
            ],
        ],
    ],
];
