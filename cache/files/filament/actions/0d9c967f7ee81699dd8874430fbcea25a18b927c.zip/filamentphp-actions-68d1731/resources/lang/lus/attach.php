<?php

return [

    'single' => [

        'label' => 'Dahbelh',

        'modal' => [

            'heading' => ':Label dahbelhna',

            'fields' => [

                'record_id' => [
                    'label' => 'Record',
                ],

            ],

            'actions' => [

                'attach' => [
                    'label' => 'Dahbelh',
                ],

                'attach_another' => [
                    'label' => 'Pakhat dahbelh a adang dahbelh lehna',
                ],

            ],

        ],

        'notifications' => [

            'attached' => [
                'title' => 'Dahbelh a ni.',
            ],

        ],

    ],

];
