<?php

return [

    'confirmation' => 'Apakah Anda yakin ingin melakukan ini?',

    'actions' => [

        'cancel' => [
            'label' => 'Batal',
        ],

        'confirm' => [
            'label' => 'Konfirmasi',
        ],

        'submit' => [
            'label' => 'Kirim',
        ],

    ],

];
