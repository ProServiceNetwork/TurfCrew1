<?php

return [

    'throttled' => [
        'title' => 'Troppi tentativi',
        'body' => 'Per favore riprova tra :seconds secondi.',
    ],

];
