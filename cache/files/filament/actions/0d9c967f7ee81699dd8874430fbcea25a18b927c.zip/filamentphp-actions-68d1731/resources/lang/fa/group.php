<?php

return [

    'trigger' => [
        'label' => 'عملیات',
    ],

];
