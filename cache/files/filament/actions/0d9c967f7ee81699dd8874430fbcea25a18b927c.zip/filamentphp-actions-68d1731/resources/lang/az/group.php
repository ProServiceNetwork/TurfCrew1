<?php

return [

    'trigger' => [
        'label' => 'Tətikləyicilər',
    ],

];
