<?php

return [

    'single' => [

        'label' => 'Խմբագրել',

        'modal' => [

            'heading' => 'Խմբագրել :labelը',

            'actions' => [

                'save' => [
                    'label' => 'Պահպանել',
                ],

            ],

        ],

        'notifications' => [

            'saved' => [
                'title' => 'Պահպանվել է',
            ],

        ],

    ],

];
