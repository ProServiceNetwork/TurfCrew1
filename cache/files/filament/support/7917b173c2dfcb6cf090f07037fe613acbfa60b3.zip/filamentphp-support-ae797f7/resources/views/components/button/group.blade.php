<div {{ $attributes->class(['fi-btn-group']) }}>
    {{ $slot }}
</div>
