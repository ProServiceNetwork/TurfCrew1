<h2
    {{ $attributes->class(['fi-section-header-heading']) }}
>
    {{ $slot }}
</h2>
