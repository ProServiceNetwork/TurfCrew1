<p
    {{ $attributes->class(['fi-modal-description']) }}
>
    {{ $slot }}
</p>
