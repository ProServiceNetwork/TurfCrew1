<?php

return [

    'messages' => [
        'uploading_file' => 'Fayl yuklanmoqda...',
    ],

];
