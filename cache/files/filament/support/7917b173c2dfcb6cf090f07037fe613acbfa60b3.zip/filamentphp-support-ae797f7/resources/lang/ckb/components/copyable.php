<?php

return [

    'messages' => [
        'copied' => 'لەبەرگیرایەوە',
    ],

];
