<?php

return [

    'actions' => [

        'close' => [
            'label' => 'ปิด',
        ],

    ],

];
