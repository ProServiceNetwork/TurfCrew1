<?php

return [

    'messages' => [

        'uploading_file' => 'Nahrávání souboru...',

    ],

];
