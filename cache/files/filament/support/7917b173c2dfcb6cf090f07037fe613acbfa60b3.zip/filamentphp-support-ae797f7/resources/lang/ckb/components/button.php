<?php

return [

    'messages' => [
        'uploading_file' => 'بارکردنی پەڕگە...',
    ],

];
