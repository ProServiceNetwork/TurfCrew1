<?php

namespace Filament\Support\Commands\Exceptions;

use Exception;

class SuccessCommandOutput extends Exception {}
