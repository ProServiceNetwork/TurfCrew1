<?php

return [

    'distinct' => [
        'must_be_selected' => 'حداقل یک :attribute باید انتخاب شود.',
        'only_one_must_be_selected' => 'فقط یک :attribute باید انتخاب شود.',
    ],

];
