<?php

return [

    'distinct' => [
        'must_be_selected' => 'Најмање један :attribute мора бити изабран.',
        'only_one_must_be_selected' => 'Само један :attribute може бити изабран.',
    ],

];
