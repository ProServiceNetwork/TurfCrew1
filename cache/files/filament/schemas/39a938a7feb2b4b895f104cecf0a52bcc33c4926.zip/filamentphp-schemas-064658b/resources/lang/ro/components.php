<?php

return [

    'wizard' => [

        'actions' => [

            'previous_step' => [
                'label' => 'Pasul anterior',
            ],

            'next_step' => [
                'label' => 'Pasul următor',
            ],

        ],

    ],

];
