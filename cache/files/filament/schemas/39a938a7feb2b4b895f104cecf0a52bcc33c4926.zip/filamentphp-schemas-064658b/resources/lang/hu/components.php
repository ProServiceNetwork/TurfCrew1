<?php

return [

    'wizard' => [

        'actions' => [

            'previous_step' => [
                'label' => 'Előző lépés',
            ],

            'next_step' => [
                'label' => 'Következő lépés',
            ],

        ],

    ],

];
