<?php

return [

    'wizard' => [

        'actions' => [

            'previous_step' => [
                'label' => 'ወደ ኋላ',
            ],

            'next_step' => [
                'label' => 'ቀጣይ',
            ],

        ],

    ],

];
