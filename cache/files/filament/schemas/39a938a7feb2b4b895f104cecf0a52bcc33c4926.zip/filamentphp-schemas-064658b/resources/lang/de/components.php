<?php

return [

    'wizard' => [

        'actions' => [

            'previous_step' => [
                'label' => 'Zurück',
            ],

            'next_step' => [
                'label' => 'Weiter',
            ],

        ],

    ],

];
