<?php

return [

    'wizard' => [

        'actions' => [

            'previous_step' => [
                'label' => '이전',
            ],

            'next_step' => [
                'label' => '다음',
            ],

        ],

    ],

];
