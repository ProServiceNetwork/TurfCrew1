<?php

return [

    'wizard' => [

        'actions' => [

            'previous_step' => [
                'label' => 'पछाडि',
            ],

            'next_step' => [
                'label' => 'अर्को',
            ],

        ],

    ],

];
