<?php

return [

    'wizard' => [

        'actions' => [

            'previous_step' => [
                'label' => '上一步',
            ],

            'next_step' => [
                'label' => '下一步',
            ],

        ],

    ],

];
