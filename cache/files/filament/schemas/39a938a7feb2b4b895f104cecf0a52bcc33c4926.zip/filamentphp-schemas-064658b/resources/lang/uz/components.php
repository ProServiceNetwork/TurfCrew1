<?php

return [

    'wizard' => [

        'actions' => [

            'previous_step' => [
                'label' => 'Orqaga',
            ],

            'next_step' => [
                'label' => 'Keyingi',
            ],

        ],

    ],

];
