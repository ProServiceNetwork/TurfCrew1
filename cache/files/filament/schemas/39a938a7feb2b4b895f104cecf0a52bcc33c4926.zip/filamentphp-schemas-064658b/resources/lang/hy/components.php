<?php

return [

    'wizard' => [

        'actions' => [

            'previous_step' => [
                'label' => 'Նախորդը',
            ],

            'next_step' => [
                'label' => 'Հաջորդը',
            ],

        ],

    ],

];
