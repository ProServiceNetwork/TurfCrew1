<?php

return [

    'wizard' => [

        'actions' => [

            'previous_step' => [
                'label' => 'Back',
            ],

            'next_step' => [
                'label' => 'Next',
            ],

        ],

    ],

];
