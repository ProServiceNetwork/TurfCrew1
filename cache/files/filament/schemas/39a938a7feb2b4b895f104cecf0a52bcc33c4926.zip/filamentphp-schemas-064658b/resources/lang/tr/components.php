<?php

return [

    'wizard' => [

        'actions' => [

            'previous_step' => [
                'label' => 'Geri',
            ],

            'next_step' => [
                'label' => 'İleri',
            ],

        ],

    ],

];
