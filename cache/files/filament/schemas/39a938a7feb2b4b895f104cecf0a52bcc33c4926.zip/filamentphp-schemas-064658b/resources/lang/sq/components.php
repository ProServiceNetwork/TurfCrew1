<?php

return [

    'wizard' => [

        'actions' => [

            'previous_step' => [
                'label' => 'Pas',
            ],

            'next_step' => [
                'label' => 'Para',
            ],

        ],

    ],

];
