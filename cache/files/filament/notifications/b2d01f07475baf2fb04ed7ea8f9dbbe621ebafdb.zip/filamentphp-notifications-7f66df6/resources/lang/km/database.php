<?php

return [

    'modal' => [

        'heading' => 'ដំណឹង',

        'actions' => [

            'clear' => [
                'label' => 'សំអាត',
            ],

            'mark_all_as_read' => [
                'label' => 'សម្គាល់ថាបានអានទាំងអស់ហើយ',
            ],

        ],

        'empty' => [
            'heading' => 'គ្នានដំណឹង',
            'description' => 'សូមពិនិត្យម្តងទៀតនៅពេលក្រោយ.',
        ],

    ],

];
