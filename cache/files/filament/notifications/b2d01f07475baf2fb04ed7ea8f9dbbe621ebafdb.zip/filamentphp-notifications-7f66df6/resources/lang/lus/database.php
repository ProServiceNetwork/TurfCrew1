<?php

return [

    'modal' => [

        'heading' => 'Notifications',

        'actions' => [

            'clear' => [
                'label' => 'Clear',
            ],

            'mark_all_as_read' => [
                'label' => 'Chhiar vek tawh ah dah rawh',
            ],

        ],

        'empty' => [
            'heading' => 'Notifications a awmlo',
            'description' => 'Nakinah ilo check leh dawn nia.',
        ],

    ],

];
