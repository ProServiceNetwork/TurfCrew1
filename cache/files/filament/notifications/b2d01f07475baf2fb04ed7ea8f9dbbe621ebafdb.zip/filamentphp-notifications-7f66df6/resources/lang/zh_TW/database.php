<?php

return [

    'modal' => [

        'heading' => '通知',

        'actions' => [

            'clear' => [
                'label' => '清除',
            ],

            'mark_all_as_read' => [
                'label' => '標記為已讀',
            ],

        ],

        'empty' => [
            'heading' => '沒有通知',
            'description' => '請稍後再查看。',
        ],

    ],

];
