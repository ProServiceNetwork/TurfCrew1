<?php

return [

    'modal' => [

        'heading' => 'نوٹیفکیشنز',

        'actions' => [

            'clear' => [
                'label' => 'صاف کریں',
            ],

            'mark_all_as_read' => [
                'label' => 'سب کو پڑھا ہوا نشان لگائیں',
            ],

        ],

        'empty' => [
            'heading' => 'کوئی نوٹیفکیشن نہیں',
            'description' => 'براہ کرم بعد میں دوبارہ چیک کریں۔',
        ],

    ],

];
