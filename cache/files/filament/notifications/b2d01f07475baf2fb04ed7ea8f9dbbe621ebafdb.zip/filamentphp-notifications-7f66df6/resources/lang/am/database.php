<?php

return [

    'modal' => [

        'heading' => 'ማሳወቂያዎች',
        'actions' => [

            'clear' => [

                'label' => 'አፅዳ',
            ],
            'mark_all_as_read' => [

                'label' => 'ሁሉም ተነበዋል',
            ],
        ],
        'empty' => [

            'heading' => 'ምንም አዲስ ነገር የለም',
            'description' => 'እባክዎ ከትንሽ ቆይታ በኋላ ይመለሱ',
        ],
    ],
];
