<?php

return [

    'field' => [
        'label' => 'بحث عام',
        'placeholder' => 'بحث',
    ],

    'no_results_message' => 'لم يتم العثور على نتائج عن البحث.',

];
