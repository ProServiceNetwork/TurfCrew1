<?php

return [

    'title' => 'Ohjausnäkymä',

    'actions' => [

        'filter' => [

            'label' => 'Suodatin',

            'modal' => [

                'heading' => 'Suodatin',

                'actions' => [

                    'apply' => [

                        'label' => 'Käytä',

                    ],

                ],

            ],

        ],

    ],

];
