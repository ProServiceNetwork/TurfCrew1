<?php

return [

    'title' => 'ዳሽቦርድ',
    'actions' => [

        'filter' => [

            'label' => 'አጣራ',
            'modal' => [

                'heading' => 'አጣራ',
                'actions' => [

                    'apply' => [

                        'label' => 'ተግብር',
                    ],
                ],
            ],
        ],
    ],
];
