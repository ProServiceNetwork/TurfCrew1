<?php

return [

    'actions' => [

        'logout' => [
            'label' => 'Kirjaudu ulos',
        ],

    ],

    'welcome' => 'Tervetuloa',

];
