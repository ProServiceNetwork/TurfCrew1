<?php

return [

    'title' => 'بینینی :label',

    'breadcrumb' => 'بینین',

    'content' => [

        'tab' => [
            'label' => 'بینین',
        ],

    ],

];
