<?php

return [

    'breadcrumb' => 'Liste',

];
