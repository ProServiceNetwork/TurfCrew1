<?php

return [

    'field' => [
        'label' => 'ሙሉ ፍለጋ',
        'placeholder' => 'ፈልግ',
    ],
    'no_results_message' => 'ምንም የፍለጋ ውጤቶች አልተገኙም።',
];
