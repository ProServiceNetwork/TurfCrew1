<?php

return [

    'field' => [
        'label' => 'Búsqueda global',
        'placeholder' => 'Buscar',
    ],

    'no_results_message' => 'No se han encontrado resultados.',

];
