<?php

return [

    'subject' => 'Bejelentkezési kód',

    'lines' => [
        'A bejelentkezési kódod: :code',
        'Ez a kód egy perc múlva lejár.|Ez a kód :minutes perc múlva lejár.',
    ],

];
