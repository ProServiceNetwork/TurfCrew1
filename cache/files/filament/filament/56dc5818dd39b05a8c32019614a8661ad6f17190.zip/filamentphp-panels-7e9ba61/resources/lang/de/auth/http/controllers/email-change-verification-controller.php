<?php

return [

    'notifications' => [

        'verified' => [
            'title' => 'E-Mail-Adresse geändert',
            'body' => 'Ihre E-Mail-Adresse wurde erfolgreich zu :email geändert.',
        ],

    ],

];
