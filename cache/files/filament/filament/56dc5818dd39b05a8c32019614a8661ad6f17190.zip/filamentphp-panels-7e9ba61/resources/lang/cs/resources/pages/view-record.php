<?php

return [

    'title' => 'Zobrazit :label',

    'breadcrumb' => 'Zobrazit',

    'navigation_label' => 'Zobrazit',

    'content' => [

        'tab' => [
            'label' => 'Zobrazit',
        ],

    ],

];
