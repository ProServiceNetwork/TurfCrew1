<?php

return [

    'form' => [

        'actions' => [

            'save' => [
                'label' => 'Guardar cambios',
            ],

        ],

    ],

    'notifications' => [

        'saved' => [
            'title' => 'Guardados',
        ],

    ],

];
