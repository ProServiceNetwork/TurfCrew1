<?php

return [

    'title' => 'Kétfaktoros hitelesítés (2FA) beállítása',

    'heading' => 'Kétfaktoros hitelesítés beállítása',

    'subheading' => 'A 2FA további biztonsági réteget ad a fiókodhoz azáltal, hogy bejelentkezéskor egy második ellenőrzési formát is megkövetel.',

    'actions' => [

        'continue' => [
            'label' => 'Folytatás',
        ],

    ],

];
