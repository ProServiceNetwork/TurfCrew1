<?php

return [
    'title' => 'Nastavte dvoufázové ověření (2FA)',

    'heading' => 'Nastavte dvoufázové ověření',

    'subheading' => '2FA přidává další úroveň zabezpečení Vašeho účtu tím, že při přihlášení vyžaduje druhou formu ověření.',

    'actions' => [
        'continue' => [
            'label' => 'Pokračovat',
        ],
    ],
];
