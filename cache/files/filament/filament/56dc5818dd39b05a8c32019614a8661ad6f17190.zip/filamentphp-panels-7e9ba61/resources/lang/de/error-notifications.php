<?php

return [

    'title' => 'Fehler beim Laden der Seite',

    'body' => 'Beim Laden dieser Seite ist ein Fehler aufgetreten. Bitte versuchen Sie es später erneut.',

];
