<?php

return [

    'form' => [

        'actions' => [

            'save' => [
                'label' => 'Sauvegarder les modifications',
            ],

        ],

    ],

    'notifications' => [

        'saved' => [
            'title' => 'Sauvegardé',
        ],

    ],

];
