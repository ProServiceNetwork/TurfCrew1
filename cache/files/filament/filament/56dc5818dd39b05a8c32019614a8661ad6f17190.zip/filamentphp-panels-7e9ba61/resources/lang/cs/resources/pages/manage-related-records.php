<?php

return [

    'title' => 'Spravovat :label :relationship',
];
