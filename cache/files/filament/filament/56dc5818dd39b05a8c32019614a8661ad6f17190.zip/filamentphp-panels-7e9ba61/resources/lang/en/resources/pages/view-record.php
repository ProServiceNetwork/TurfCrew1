<?php

return [

    'title' => 'View :label',

    'breadcrumb' => 'View',

    'navigation_label' => 'View',

    'content' => [

        'tab' => [
            'label' => 'View',
        ],

    ],

];
