<?php

return [

    'title' => 'Ver :label',

    'breadcrumb' => 'Ver',

    'navigation_label' => 'Ver',

    'content' => [

        'tab' => [
            'label' => 'Ver',
        ],

    ],

];
