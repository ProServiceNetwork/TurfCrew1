<?php

return [

    'body' => 'Vous avez des modifications non sauvegardées. Êtes-vous sûr de vouloir quitter cette page ?',

];
