<?php

return [

    'title' => ':labelን እይ',

    'breadcrumb' => 'ተመልከት',

    'content' => [

        'tab' => [
            'label' => 'ተመልከት',
        ],

    ],

];
