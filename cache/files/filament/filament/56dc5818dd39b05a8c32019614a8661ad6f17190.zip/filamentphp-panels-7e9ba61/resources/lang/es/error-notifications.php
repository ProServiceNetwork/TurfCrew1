<?php

return [

    'title' => 'Error al cargar la página',

    'body' => 'Ocurrió un error al intentar cargar esta página. Por favor, inténtelo de nuevo más tarde.',

];
