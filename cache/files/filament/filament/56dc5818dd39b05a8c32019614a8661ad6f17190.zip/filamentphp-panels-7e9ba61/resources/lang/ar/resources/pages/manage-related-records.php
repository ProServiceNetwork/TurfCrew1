<?php

return [

    'title' => 'إدارة :label :relationship',

];
