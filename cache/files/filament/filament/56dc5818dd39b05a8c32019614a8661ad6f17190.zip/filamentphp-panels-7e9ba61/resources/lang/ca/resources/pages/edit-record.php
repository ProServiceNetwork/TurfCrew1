<?php

return [

    'title' => 'Editar :label',

    'breadcrumb' => 'Editar',

    'form' => [

        'actions' => [

            'cancel' => [
                'label' => 'Cancel·lar',
            ],

            'save' => [
                'label' => 'Desar canvis',
            ],

        ],

    ],

    'content' => [

        'tab' => [
            'label' => 'Editar',
        ],

    ],

    'notifications' => [

        'saved' => [
            'title' => 'Canvis desats',
        ],

    ],

];
