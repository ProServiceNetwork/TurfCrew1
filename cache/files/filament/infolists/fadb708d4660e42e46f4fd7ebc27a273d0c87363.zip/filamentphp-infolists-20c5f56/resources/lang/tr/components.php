<?php

return [

    'entries' => [

        'text' => [

            'actions' => [
                'collapse_list' => ':count kayıt az göster',
                'expand_list' => ':count kayıt daha göster',
            ],

            'more_list_items' => 've :count kayıt daha',

        ],

        'key_value' => [

            'columns' => [

                'key' => [
                    'label' => 'Anahtar',
                ],

                'value' => [
                    'label' => 'Değer',
                ],

            ],

            'placeholder' => 'Kayıt yok',

        ],

    ],

];
