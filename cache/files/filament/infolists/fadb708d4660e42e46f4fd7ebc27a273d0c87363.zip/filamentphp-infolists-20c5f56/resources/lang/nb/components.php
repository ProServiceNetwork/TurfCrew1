<?php

return [

    'entries' => [

        'text' => [

            'actions' => [
                'collapse_list' => 'Vis :count mindre',
                'expand_list' => 'Vis :count til',
            ],

            'more_list_items' => 'og :count til',

        ],

        'key_value' => [

            'columns' => [

                'key' => [
                    'label' => 'Nøkkel',
                ],

                'value' => [
                    'label' => 'Verdi',
                ],

            ],

            'placeholder' => 'Ingen oppføringer',

        ],

    ],

];
