<?php

return [

    'entries' => [

        'text' => [

            'actions' => [
                'collapse_list' => 'Show :count less',
                'expand_list' => 'Show :count more',
            ],

            'more_list_items' => 'and :count more',

        ],

        'key_value' => [

            'columns' => [

                'key' => [
                    'label' => 'Key',
                ],

                'value' => [
                    'label' => 'Value',
                ],

            ],

            'placeholder' => 'No entries',

        ],

    ],

];
