<?php

return [

    'entries' => [

        'text' => [

            'actions' => [

                'collapse_list' => 'ያነሰ :count አሳይ',
                'expand_list' => 'ተጨማሪ :count አሳይ',
            ],
            'more_list_items' => 'እና ተጨማሪ :count',
        ],
        'key_value' => [

            'columns' => [

                'key' => [

                    'label' => 'ስም',
                ],
                'value' => [

                    'label' => 'ዋጋ',
                ],
            ],
            'placeholder' => 'ምንም ግበኣቶች የሉም',
        ],
    ],
];
