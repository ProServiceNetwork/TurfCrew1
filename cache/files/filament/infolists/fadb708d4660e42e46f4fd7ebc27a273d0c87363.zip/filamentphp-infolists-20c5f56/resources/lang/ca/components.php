<?php

return [

    'entries' => [

        'text' => [

            'actions' => [
                'collapse_list' => 'Mostrar-ne :count menys',
                'expand_list' => 'Mostrar-ne :count més',
            ],

            'more_list_items' => 'i :count més',

        ],

        'key_value' => [

            'columns' => [

                'key' => [
                    'label' => 'Clau',
                ],

                'value' => [
                    'label' => 'Valor',
                ],

            ],

            'placeholder' => 'No hi ha entrades',

        ],

    ],

];
