<?php

return [

    'entries' => [

        'text' => [

            'actions' => [
                'collapse_list' => ':count in tilang tlem rawh',
                'expand_list' => ':count in tilang tam rawh',
            ],

            'more_list_items' => 'and :count more',

        ],

        'key_value' => [

            'columns' => [

                'key' => [
                    'label' => 'Key',
                ],

                'value' => [
                    'label' => 'Value',
                ],

            ],

            'placeholder' => 'No entries',

        ],

    ],

];
