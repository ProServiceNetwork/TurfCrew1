<?php

return [

    'actions' => [

        'filter' => [
            'label' => 'تصفية',
        ],

    ],

];
