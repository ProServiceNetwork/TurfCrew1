<?php

return [

    'actions' => [

        'filter' => [
            'label' => 'Bộ lọc',
        ],

    ],

];
