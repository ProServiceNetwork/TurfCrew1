<?php

namespace Filament\Widgets\View;

class WidgetsIconAlias
{
    const CHART_WIDGET_FILTER = 'widgets::chart-widget.filter';
}
